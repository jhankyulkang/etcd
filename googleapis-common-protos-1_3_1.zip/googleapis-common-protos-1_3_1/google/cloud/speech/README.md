# Introduction

Google Cloud Speech API provides speech recognition as a service.